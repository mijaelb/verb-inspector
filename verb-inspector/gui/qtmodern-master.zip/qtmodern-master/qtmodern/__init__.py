__version__ = '0.1.4'
""" str: Package version. """
